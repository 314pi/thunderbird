pref("extensions.{480adee0-f020-4fef-917d-b05502b17aaf}.minimizeOnStart", false);
pref("extensions.{480adee0-f020-4fef-917d-b05502b17aaf}.minimizeOnClose", true);
pref("extensions.{480adee0-f020-4fef-917d-b05502b17aaf}.minimizeOnEsc", false);
pref("extensions.{480adee0-f020-4fef-917d-b05502b17aaf}.initDelay", 100);